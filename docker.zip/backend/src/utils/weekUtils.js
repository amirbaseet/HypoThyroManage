function getCurrentWeek() {
    let today = new Date();
    
    let startOfWeek = new Date(today);
    startOfWeek.setDate(today.getDate() - today.getDay() + 1);
    startOfWeek.setHours(0, 0, 0, 0);

    let endOfWeek = new Date(startOfWeek);
    endOfWeek.setDate(startOfWeek.getDate() + 6);
    endOfWeek.setHours(23, 59, 59, 999);

    return { weekStart: startOfWeek, weekEnd: endOfWeek };
}

module.exports = { getCurrentWeek };
